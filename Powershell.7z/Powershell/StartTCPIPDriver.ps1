Get-Service "TCP/IP NetBIOS Helper" | Start-Service
Get-Service "IP Helper" | Start-Service
Get-Service "DNS Client" | Start-Service
Get-Service "WinHTTP Web Proxy Auto-Discovery Service" | Start-Service
Get-Service "DHCP Client" | Start-Service
Get-Service "IPSec Policy Agent" | Start-Service
Get-Service "Network List Service" | Start-Service
Get-Service "Network Location Awareness" | Start-Service
Get-Service "Client for NFS" | Start-Service